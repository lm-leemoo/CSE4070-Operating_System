#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H
#include "threads/thread.h"
#include "lib/kernel/list.h"
#include "vm/page.h" //prj4
#include "vm/swap.h"
#include "vm/page.h"
#include "threads/palloc.h"
struct fte
{
    void *fr;
    struct thread *fr_thread;
    struct supplemental_pagetable* sup_page_table;
    struct list_elem le;
};
bool install_page (void *upage, void *kpage, bool writable);
tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);
bool grow_stack(void *address); //prj4
struct fte* allocate_frame(enum palloc_flags flag);
struct list_elem* get_elem(void);
bool less_func(const struct hash_elem *e, const struct hash_elem *ee, void *aux);
#endif /* userprog/process.h */
