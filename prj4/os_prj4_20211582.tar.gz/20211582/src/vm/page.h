#ifndef PAGE_H
#define PAGE_H
#include <hash.h>
enum top 
{
    PAGE_FILE,
    PAGE_SWAP
};

struct supplemental_pagetable
{
    enum top t;
    struct hash_elem he;
    struct file *f;
    size_t read_bytes;
    size_t zero_bytes;
    void *u_vaddr;
    bool mem_load;
    bool read_only;
    bool flag;
    size_t offset;
    size_t swap;
};

bool page_load(void *address, struct supplemental_pagetable *sup_page_table);
bool read_success(void *f, void *address, uintptr_t read_bytes, uintptr_t offset);
void eliminate(struct hash_elem *he, void *aux);
unsigned hash_func(const struct hash_elem *e, void *aux);
#endif