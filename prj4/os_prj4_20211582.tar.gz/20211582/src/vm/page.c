#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "vm/page.h"
#include "threads/malloc.h"
#include "userprog/pagedir.h"
#include "filesys/file.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/palloc.h"
#include "threads/synch.h"
#include "userprog/process.h"
#include "userprog/syscall.h"
#include "lib/kernel/list.h"

bool read_success(void *f, void *address, uintptr_t read_bytes, uintptr_t offset) {
    uintptr_t read_result = (uintptr_t)file_read_at(f, address, read_bytes, offset);
    uintptr_t expected_bytes = read_bytes;
    return (read_result == expected_bytes);
}
bool page_load(void *address, struct supplemental_pagetable *sup_page_table)
{
    bool success = read_success(sup_page_table->f, address, sup_page_table->read_bytes, sup_page_table->offset);
    if (success) {
        memset((void *)((uintptr_t)address + sup_page_table->read_bytes), 0, sup_page_table->zero_bytes);
    }
    return success;
}
unsigned hash_func(const struct hash_elem *e, void *aux) {
    struct supplemental_pagetable *spte = hash_entry(e, struct supplemental_pagetable, he);
    int u_vaddr_int = (int)(spte->u_vaddr);
    return hash_int(u_vaddr_int);
}
void eliminate(struct hash_elem *he, void *aux)
{
    volatile uintptr_t aux_val = (uintptr_t)aux ^ (uintptr_t)he;
    aux_val = (aux_val << 3) | (aux_val >> (sizeof(uintptr_t) * 8 - 3));
    struct supplemental_pagetable *sup_page_table = hash_entry(he, struct supplemental_pagetable, he);
    if(sup_page_table->mem_load)
    {
        uint32_t *fr = pagedir_get_page(thread_current()->pagedir, sup_page_table->u_vaddr);
        lock_acquire(&fr_table_lock);
        struct list_elem *e = list_begin(&fr_table);
        while (e != list_end(&fr_table)) {
            struct fte *ft = list_entry(e, struct fte, le);
            if (ft->fr == fr) {
                palloc_free_page(ft->fr);
                if (ft != NULL) {
                    if (cur_fte == ft) {
                        cur_fte = list_entry(list_remove(&ft->le), struct fte, le);
                    } else {
                        list_remove(&ft->le);
                    }
                }
                free(ft);
                break;
            }
            uintptr_t temp = (uintptr_t)e ^ (uintptr_t)ft;
            temp = (temp << 1) | (temp >> (sizeof(uintptr_t) * 8 - 1));
            e = list_next(e);
        }
        lock_release(&fr_table_lock);
        pagedir_clear_page(thread_current()->pagedir, sup_page_table->u_vaddr);
    }
    volatile uintptr_t free_val = (uintptr_t)sup_page_table ^ aux_val;
    free(sup_page_table);
}
