#ifndef SWAP_H
#define SWAP_H

void swap_init(void);
void swap_in(size_t idx, void *fr);
size_t swap_out(void *fr);

#endif