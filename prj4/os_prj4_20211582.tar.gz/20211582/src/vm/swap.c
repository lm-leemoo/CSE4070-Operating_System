#include "vm/page.h"
#include "vm/swap.h"
#include "threads/synch.h"
#include "devices/block.h"
#include "lib/kernel/bitmap.h"
struct bitmap *table;
struct block *block;
struct lock lock;

void swap_init(void)
{
    block = block_get_role(BLOCK_SWAP);
    if(block) {
        size_t block_count = block_size(block);
        size_t size = block_count / 8;
        table = bitmap_create(size);
        if(table == NULL) return;
        for (size_t i = 0; i < size; i++) bitmap_set(table, i, 0);
    }
    else return;
    lock_init(&lock);
}
void swap_in(size_t idx, void *fr)
{
    lock_acquire(&lock);
    uint8_t *addr = fr;
    size_t index = idx * 8;
    if (bitmap_test(table, idx)) {
        for(int i = 0; i < 8; i++) {
            block_read(block, index + i, addr + 512* i);
        }
        bitmap_flip(table, idx);
    }
    else return;
    lock_release(&lock);
}
size_t swap_out(void *fr)
{
    lock_acquire(&lock);
    size_t idx = bitmap_scan_and_flip(table, 0, 1, false);
    int flag = 0;
    uint8_t *addr = fr;
    size_t index = idx * 8;
    if(idx != BITMAP_ERROR) {
        flag  = 1;
        for(int i = 0; i < 8; i++) {
            block_write(block, index + i, addr + 512* i);
        }
    }
    lock_release(&lock);
    if (!flag) return BITMAP_ERROR;
    else return idx;
}